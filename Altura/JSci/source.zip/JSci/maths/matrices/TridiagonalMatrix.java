package JSci.maths.matrices;

public interface TridiagonalMatrix extends SquareMatrix {}

