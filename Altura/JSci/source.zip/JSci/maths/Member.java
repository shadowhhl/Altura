package JSci.maths;

/**
 * This interface defines a member of a set.
 * @version 1.0
 * @author Mark Hale
 */
public interface Member extends java.io.Serializable {
	Object getSet();
}
