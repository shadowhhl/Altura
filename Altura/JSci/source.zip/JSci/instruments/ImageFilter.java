package JSci.instruments;

/** An object that filters frames */

public interface ImageFilter extends ImageSource, ImageSink {
}
