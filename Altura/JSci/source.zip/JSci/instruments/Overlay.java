package JSci.instruments;

import java.awt.*;

/** This class defines an object that can be put on an image */
public interface Overlay {

    /** draw */
    void paint(Graphics g);
}
