package JSci.chemistry;

/**
* An ionic bond between two atoms.
*/
public class IonicBond extends Bond {
        public IonicBond(Atom a, Atom b) {
                super(a, b);
        }
}

